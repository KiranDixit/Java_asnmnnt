package Banking_Domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Bean_Loan {
	@Id
	String loan_id;
	@Column
	String loan_purpose;
	@Column
	String loan_details;
	@Column
	String loan_accountid;
	@Column
	String loan_customerid;

	public String getLoan_id() {
		return loan_id;
	}

	public void setLoan_id(String loan_id) {
		this.loan_id = loan_id;
	}

	public String getLoan_purpose() {
		return loan_purpose;
	}

	public void setLoan_purpose(String loan_purpose) {
		this.loan_purpose = loan_purpose;
	}

	public String getLoan_details() {
		return loan_details;
	}

	public void setLoan_details(String loan_details) {
		this.loan_details = loan_details;
	}

	public String getLoan_accountid() {
		return loan_accountid;
	}

	public void setLoan_accountid(String loan_accountid) {
		this.loan_accountid = loan_accountid;
	}

	public String getLoan_customerid() {
		return loan_customerid;
	}

	public void setLoan_customerid(String loan_customerid) {
		this.loan_customerid = loan_customerid;
	}

	@Override
	public String toString() {
		return "Bean_Class [loan_id=" + loan_id + ", loan_purpose=" + loan_purpose + ", loan_details=" + loan_details
				+ ", loan_accountid=" + loan_accountid + ", loan_customerid=" + loan_customerid + "]";
	}

}
