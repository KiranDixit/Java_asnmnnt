package Banking_Domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity
public class Bean_Bank implements Serializable {
	@Id
	int bank_id;
	@Column
	String bank_name;
	@Column
	String bank_location;

	public int getBank_id() {
		return bank_id;
	}

	public void setBank_id(int bank_id) {
		this.bank_id = bank_id;
	}

	public String getBank_name() {
		return bank_name;
	}

	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}

	public String getBank_location() {
		return bank_location;
	}

	public void setBank_location(String bank_location) {
		this.bank_location = bank_location;
	}

	@Override
	public String toString() {
		return "Bean_Bank [bank_id=" + bank_id + ", bank_name=" + bank_name + ", bank_location=" + bank_location + "]";
	}

}
