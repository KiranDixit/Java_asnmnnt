package Banking_Domain;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class Bank_Doman_Main {
	
	StandardServiceRegistry ssr;
	Metadata meta;
	SessionFactory sessionFactory;
	Session session;
	Transaction transaction;
	
	public void connect() {
		 ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
		 meta = new MetadataSources(ssr).getMetadataBuilder().build();
		 sessionFactory = meta.getSessionFactoryBuilder().build();
		 session = sessionFactory.openSession();
		 
	}
	
	@RequestMapping("/")
	public String bank() {
		return "bank";
	}
	
	@RequestMapping("/employee")
	public String employee(@ModelAttribute("Bean_Bank") Bean_Bank bean, Model model) {
		try {
		connect();
		transaction = session.beginTransaction();
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("inside the connect");
		}
		try {
		model.addAttribute("bank_id",bean.getBank_id());
		model.addAttribute("bank_name",bean.getBank_name());
		model.addAttribute("bank_location",bean.getBank_location());
		session.save(bean);
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("inside the bean");
		}
		transaction.commit();
		session.close();
		return "employee";  
	}

	
	@RequestMapping("/customer")
	public String customer(@ModelAttribute("Bean_Employee") Bean_Employee bean,@ModelAttribute("Bean_Bank") Bean_Bank beans, Model model) {
		connect();
		transaction = session.beginTransaction();
		model.addAttribute("employee_id",bean.getEmployee_id());
		model.addAttribute("employee_name",bean.getEmployee_name());
		model.addAttribute("bank_id",beans.getBank_id());
		model.addAttribute("bank_name",beans.getBank_name());
		model.addAttribute("bank_location",beans.getBank_location());
		

		session.save(bean);
		transaction.commit();
		return "customer";
	}
	
	
	@RequestMapping("/account")
	public String account(@ModelAttribute("Bean_Customer") Bean_Customer bean, Model model) {
		connect();
		transaction = session.beginTransaction();
		model.addAttribute("customer_accountno",bean.getCustomer_accountno());
		model.addAttribute("customer_id",bean.getCustomer_id());
		model.addAttribute("customer_phoneno",bean.getCustomer_phoneno());
		model.addAttribute("customer_name",bean.getCustomer_name());
		model.addAttribute("customer_address",bean.getCustomer_address());
		
		session.save(bean);
		transaction.commit();
		return "account";
	}

	
	@RequestMapping("/loan")
	public String loan(@ModelAttribute("Bean_Loan") Bean_Loan bean,@ModelAttribute("Bean_Account") Bean_Account bean1, Model model) {
//		connect();
//		transaction = session.beginTransaction();
		model.addAttribute("loan_accountid",bean.getLoan_accountid());
		model.addAttribute("loan_accountid",bean.getLoan_customerid());
		model.addAttribute("loan_details",bean.getLoan_details());
		model.addAttribute("loan_purpose",bean.getLoan_purpose());
		model.addAttribute("loan_id",bean.getLoan_id());
		
		model.addAttribute("account_customerid", bean1.getAccount_customerid());
		model.addAttribute("account_id", bean1.getAccount_id());
		
		
//		session.save(bean1);
//		transaction.commit();
		return "loan";
	}
	
	
	

}
