package Banking_Domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity
public class Bean_Account {
	@Id
	String account_id;
	@Column
	String account_customerid;
	public String getAccount_id() {
		return account_id;
	}
	public void setAccount_id(String accunt_id) {
		this.account_id = accunt_id;
	}
	public String getAccount_customerid() {
		return account_customerid;
	}
	public void setAccount_customerid(String account_customerid) {
		this.account_customerid = account_customerid;
	}
	@Override
	public String toString() {
		return "Bean_Account [accunt_id=" + account_id + ", account_customerid=" + account_customerid + "]";
	}
	
	
}
