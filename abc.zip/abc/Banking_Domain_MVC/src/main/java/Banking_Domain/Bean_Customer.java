package Banking_Domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity
public class Bean_Customer {
	@Id
	String customer_id;	
	@Column
 	String customer_name;
	@Column
 	String customer_address;
	@Column
 	String customer_phoneno;
	@Column
 	String customer_accountno;
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getCustomer_address() {
		return customer_address;
	}
	public void setCustomer_address(String customer_address) {
		this.customer_address = customer_address;
	}
	public String getCustomer_phoneno() {
		return customer_phoneno;
	}
	public void setCustomer_phoneno(String customer_phoneno) {
		this.customer_phoneno = customer_phoneno;
	}
	public String getCustomer_accountno() {
		return customer_accountno;
	}
	public void setCustomer_accountno(String customer_accountno) {
		this.customer_accountno = customer_accountno;
	}
	@Override
	public String toString() {
		return "Bean_Employee [customer_id=" + customer_id + ", customer_name=" + customer_name + ", customer_address="
				+ customer_address + ", customer_phoneno=" + customer_phoneno + ", customer_accountno="
				+ customer_accountno + "]";
	}
}
